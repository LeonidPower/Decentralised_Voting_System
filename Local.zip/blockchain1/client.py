import socket
import threading
import random
import time
import subprocess
import pickle
import sys
from   create_poll import *
import os
import pyautogui
class Node:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.connections = []
        self.peers = set()

        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        self.sock2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock2.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    def connect_bootstrap(self):
            with open("txt\\initial_bootstraps.txt", "r") as f:
                lines = f.readlines()
                random.shuffle(lines)
                bootstrap = lines[0].strip().split(":")
                bootstrap_random = bootstrap[0]
                bootstrap_port_random = int(bootstrap[1])
                #selects random boostrap from TXT file of boostraps
                print(bootstrap_random)
                print(bootstrap_port_random)
                self.sock.connect((bootstrap_random, bootstrap_port_random))
                self.sock.sendall(f"i_am_client".encode())  
                time.sleep(0.001)
                self.sock.sendall(f"{self.host}".encode()) 
                time.sleep(0.001)  
                self.sock.sendall(f"{self.port}".encode())
                time.sleep(0.001)
   
    def send_message(self):
        while True:
            message = input()
            if message:
                
                self.connect_bootstrap() 
                
                self.sock.sendall(message.encode())
                
                if message == "create poll":
                    message = input()
                    while not message.isdigit():
                        print("Invalid input, Please enter a number.")
                        message = input()
                    a = int(message)
                    self.sock.sendall(message.encode())
                    inputs = input().split()
                    while len(inputs) != a or any(not input_val.isalpha() for input_val in inputs):
                        print("Invalid input. Please enter {} letters separated by spaces.".format(a))
                        inputs = input().split()

                    message = " ".join(inputs)
                    self.sock.sendall(message.encode())

                    message = input()
                    while not message.isalpha():
                        print("Invalid input, Please enter letters only.")
                        message = input()
                    self.sock.sendall(message.encode())
                    message = input()
                    self.sock.sendall(message.encode())
               


                elif message == "vote":
                    message = input()
                    self.sock.sendall(message.encode())
                    message = input()
                    self.sock.sendall(message.encode())
                    message = input()
                    self.sock.sendall(message.encode())

                elif message == "view poll":
                    message = input()
                    self.sock.sendall(message.encode())
                
                elif message == "view block":
                    message = input()
                    self.sock.sendall(message.encode())

                elif message == "become validator":
                    message = input("Enter your choice (Y/N): ")
                    while message not in ["Y", "y", "N", "n"]:
                        print("Invalid input. Please enter 'Y' or 'N'.")
                        message = input("Enter your choice (Y/N): ")
                    if message == "Y" or message == "y":
                        self.broadcast(message.encode(), None)
                        time.sleep(80)
                    if message == "N" or message == "n":
                        print("You have chosen not to become a validator.")
                


                self.sock.shutdown(socket.SHUT_RDWR)
                self.sock.close()
                self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

            else:
                print("Empty message, please enter a valid message.")

    def broadcast(self, data, sender):
                try:
                   if len(data) > 0:
                        self.sock.sendall(f"{data}".encode())
                except Exception as e:
                    print("Error broadcasting data:", e)
   

    def receive_message(self, conn):
        while True:
            try:
                data = conn.recv(8192)
                received_message = data.decode()

                

                if received_message == "update initial bootstraps":
                    received_data = b""
                    while len(received_data) < 1073741824: # 1 gigabyte in bytes
                        chunk = conn.recv(4096)
                        if not chunk:
                            break
                        received_data += chunk

                    if received_data:
                        with open('txt\\initial_bootstraps.txt', 'wb') as file:
                            file.write(b"")  
                            file.write(received_data)
                    print("Updated initial bootstraps")
                    self.sock.shutdown(socket.SHUT_RDWR)
                    self.sock.close()
                    self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

                elif received_message == "become validator":
                    data = conn.recv(1024)
                    bootstrapIP_next = data.decode()
                    time.sleep(0.001)
                    print("1:"+bootstrapIP_next)
                    data = conn.recv(1024)
                    bootstrapPort_next = data.decode()
                    time.sleep(0.001)
                    print("2:"+bootstrapPort_next)
                    data = conn.recv(1024)
                    bootstrapIP_previous = data.decode()
                    time.sleep(0.001)
                    print("3:"+bootstrapIP_previous)
                    data = conn.recv(1024)
                    bootstrapPort_previous = data.decode()
                    time.sleep(0.001)
                    print("4:"+bootstrapPort_previous)

                    self.sock.shutdown(socket.SHUT_RDWR)
                    self.sock.close()

                    commands = [
                        {
                            "command": r"python boot_strap.py",
                            "bootstrap_data": [
                                "4",
                                "127.0.0.1",
                                "4400",
                                bootstrapIP_next,
                                bootstrapPort_next,
                                bootstrapIP_previous,
                                bootstrapPort_previous
                            ]
                        }
                    ]

                    for cmd in commands:
                        subprocess.Popen(['start', 'cmd', '/k', cmd["command"]], shell=True)
                        time.sleep(1)

                        for data in cmd["bootstrap_data"]:
                            pyautogui.typewrite(data)
                            pyautogui.press('enter')

                    current_pid = os.getpid()
                    taskkill_command = f'taskkill /pid {current_pid} /f'
                    os.system(taskkill_command)
                    subprocess.Popen(taskkill_command, shell=True)


                elif data:
                    print(f"{received_message}")
            except Exception as e:
                print("Error receiving message:", e)
                break

    def listen_for_connections(self):   
        self.sock2.bind((self.host, self.port))
        self.sock2.listen()
        while True:
            conn, addr = self.sock2.accept()
            self.connections.append(conn)
            self.peers.add(addr[0])
            threading.Thread(target=self.receive_message, args=(conn,)).start()

    

    def update_initial_bootstraps(self):
        self.connect_bootstrap()
        self.sock.sendall(f"update initial bootstraps".encode())
        time.sleep(0.001)
        


if __name__ == '__main__':
    
    client = "127.0.0.1"
    client_port = 4400
    
    bootstrap2 = "127.0.0.1"
    bootstrap_port2 = 4100
    
    node1 = Node(client, client_port)
    print("i am client")

    threading.Thread(target=node1.update_initial_bootstraps).start()
    threading.Thread(target=node1.listen_for_connections).start()
    threading.Thread(target=node1.send_message).start()
  
    
   
