from vote_blocks import *
import pickle

obj= voteblock("poll_address", "vote_option", "vote_counter", "total_vote_counter", "user_address", "previous_hash")

with open('txt\\vote_chain.txt', 'ab') as file3:
     pickle.dump(obj, file3)


# with open('txt\\vote_chain.txt', 'rb') as file:
#     while True:
#         try:
#             obj = pickle.load(file)
#             print(obj.get_block_hash())
#         except EOFError:
#             break