import os
import hashlib
import ecdsa
import pickle
class poll:
    def __init__(self, poll_num, poll_options, poll_name):
        self.poll_num = poll_num
        self.poll_options = poll_options
        self.poll_name = poll_name
        
        self.poll_options_map = {}
        for i in range(poll_num):
            self.poll_options_map[poll_options[i]] = i
        self.vote_counter_poll_options = [0] * poll_num
        self.total_vote_counter = 0
        
        self.private_key = ecdsa.SigningKey.generate(curve=ecdsa.SECP256k1)
        self.public_key = self.private_key.get_verifying_key()
        self.poll_address = hashlib.sha256(self.public_key.to_string()).hexdigest()
        

    def get_poll_name(self):
        return self.poll_name

    def get_poll_options(self):
        return self.poll_options

    def get_poll_num(self):
        return self.poll_num

    def get_poll_options_map(self):
        return self.poll_options_map

    def get_total_vote_counter(self):
        return str(self.total_vote_counter)

    def get_vote_counter_poll_options(self):
        return str(self.vote_counter_poll_options)

    def get_vote_counter(self, vote):
        return self.vote_counter_poll_options[self.poll_options_map[vote]]
    
    def vote(self, vote):
        self.vote_counter_poll_options[self.poll_options_map[vote]] += 1
        self.total_vote_counter += 1

    def get_poll_address(self):
        return "Poll Address: {}".format(self.poll_address)
    
    def get_poll_address2(self):
        return self.poll_address


    def to_string(self):
        return f"{self.poll_name}-{self.poll_options}-{self.vote_counter_poll_options}-{self.total_vote_counter}-{self.poll_address}"

