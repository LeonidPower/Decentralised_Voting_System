import os
import hashlib
import ecdsa

class user:
    def __init__(self):
        # Generate a new private key
        self.private_key = ecdsa.SigningKey.generate(curve=ecdsa.SECP256k1)

        # Get the corresponding public key
        self.public_key = self.private_key.get_verifying_key()

        # Generate the user address from the public key
        self.user_address = hashlib.sha256(self.public_key.to_string()).hexdigest()


    def get_private_key(self):
        return self.private_key.to_string().hex()
    
    def get_public_key(self):
        return self.public_key.to_string().hex()
    
    def get_user_address(self):
        return self.user_address
    

    def to_string(self):
            return ("Private Key: " + str(self.private_key.to_string().hex()) + "\n" +
                    "Public Key: " + str(self.public_key.to_string().hex()) + "\n" +
                    "User Address: " + self.user_address)
