import subprocess
import pyautogui
import time

commands = [
    {
        "command": r"py C:\Users\leoni\Desktop\blockchain1\boot_strap.py",
        "bootstrap_data": [
            "1",
            "127.0.0.1",
            "4100",
            "127.0.0.1",
            "4200",
            "127.0.0.1",
            "4300"
        ]
    },
    {
        "command": r"py C:\Users\leoni\Desktop\blockchain2\boot_strap.py",
        "bootstrap_data": [
            "2",
            "127.0.0.1",
            "4200",
            "127.0.0.1",
            "4300",
            "127.0.0.1",
            "4100"
        ]
    },
    {
        "command": r"py C:\Users\leoni\Desktop\blockchain3\boot_strap.py",
        "bootstrap_data": [
            "3",
            "127.0.0.1",
            "4300",
            "127.0.0.1",
            "4100",
            "127.0.0.1",
            "4200"
        ]
    }
]

# Open command prompt windows and type bootstrap data
for cmd in commands:
    subprocess.Popen(['start', 'cmd', '/k', cmd["command"]], shell=True)
    time.sleep(1)

    for data in cmd["bootstrap_data"]:
        pyautogui.typewrite(data)
        pyautogui.press('enter')

# Open the client command prompt window
client_command = r"py C:\Users\leoni\Desktop\voting\client.py"
subprocess.Popen(['start', 'cmd', '/k', client_command], shell=True)
