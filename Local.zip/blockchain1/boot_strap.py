import socket
import threading
import time
import subprocess
import os
import sys
import pickle
import re
import atexit
from create_user import *
from create_poll import *
from vote_blocks import *
class Node:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.connections = []
        poll_objects = []
        self.sock2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock2.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    
        self.sock4 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock4.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
###############################################################################################    CONNECT 
    def connect_client(self, client_ip, client_port):
        try:
            self.client_ip = client_ip
            self.client_port = client_port
            self.sock4.connect((self.client_ip, self.client_port))
            self.sock4.sendall(f"{self.host}:{self.port}".encode())            
            print(f"Connected to client node {self.client_ip}:{self.client_port}")
        except Exception as e:
            print("Error connecting to client node:", e)

    def connect_bootstrap_prev(self, bootstrap_host_prev, bootstrap_port_prev):
       
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.bootstrap_host_prev = bootstrap_host_prev
            self.bootstrap_port_prev = bootstrap_port_prev

            self.sock.connect((self.bootstrap_host_prev, self.bootstrap_port_prev))
            self.sock.sendall(f"{self.host}:{self.port}".encode())            
        
            print(f"Connected to bootstrap node {self.bootstrap_host_prev}:{self.bootstrap_port_prev}")
        
        except Exception as e:
            time.sleep(1)
            self.connect_bootstrap_prev(bootstrap_host_prev, bootstrap_port_prev)    

    def connect_bootstrap_next(self, bootstrap_host_next, bootstrap_port_next):
       
        try:
            self.sock3 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock3.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.bootstrap_host_next = bootstrap_host_next
            self.bootstrap_port_next = bootstrap_port_next

            self.sock3.connect((self.bootstrap_host_next, self.bootstrap_port_next))
            self.sock3.sendall(f"{self.host}:{self.port}".encode())            

            print(f"Connected to bootstrap node {self.bootstrap_host_next}:{self.bootstrap_port_next}")
        except Exception as e:
            time.sleep(1)
            self.connect_bootstrap_next(bootstrap_host_next, bootstrap_port_next)    

    

###############################################################################################    SEND MSG
 
    def broadcast_bootstrap(self,File_Path,File_Contents,sender_ip,sender_port):
        # print("SENDER IP",sender_ip)
        # print("SENDER Port",sender_port)
        self.sock3.sendall('Update from bootstrap'.encode())
        time.sleep(0.001)
        self.sock3.sendall(str(sender_ip).encode())
        time.sleep(0.001)
        self.sock3.sendall(str(sender_port).encode())
        time.sleep(0.001)
        self.sock3.sendall(File_Path.encode())
        time.sleep(0.001)
        print("SENDING FILE NAME",str(File_Path))
        if File_Contents is None:
            with open(File_Path, 'rb') as f:
                file_contents = f.read()
            time.sleep(0.01)
            self.sock3.sendall(file_contents)
         #   print("File sent to bootstrap (None was set)")
        else:
            time.sleep(0.01)
            self.sock3.sendall(File_Contents)
        #    print("File sent to bootstrap")

    def on_death(self):
            file_path = 'txt\\initial_bootstraps.txt'
            target_line =str(self.host) + ":" + str(self.port)
            with open(file_path, 'r') as file:
                    lines = file.readlines()

            with open(file_path, 'w') as file:
                for line in lines:
                    if line.strip() != target_line.strip():
                        file.write(line)
            
            self.broadcast_bootstrap('txt\\initial_bootstraps.txt',None,self.host,self.port)

            print("Opening Bootstrap")
            self.sock.sendall('Reconnect prev'.encode())
            self.sock3.sendall('Reconnect next'.encode())
            time.sleep(0.001)
            self.sock.sendall(str(self.bootstrap_host_next).encode())
            self.sock3.sendall(str(self.bootstrap_host_prev).encode())
            time.sleep(0.001)
            #print("next ip", self.bootstrap_host_next)
            self.sock.sendall(str(self.bootstrap_port_next).encode())
            self.sock3.sendall(str(self.bootstrap_port_prev).encode())
            time.sleep(0.001)
           # print("next port", self.bootstrap_port_next)
            self.sock.shutdown(socket.SHUT_RDWR)
            self.sock.close()
          #  print("prev port", self.bootstrap_port_prev)
            self.sock3.shutdown(socket.SHUT_RDWR)
            self.sock3.close()
            print("CLIENT TERMINATED")
            current_pid = os.getpid()
            taskkill_command = f'taskkill /pid {current_pid} /f'
            os.system(taskkill_command)
            subprocess.Popen(taskkill_command, shell=True)
           

###############################################################################################    receive/LISTEN MSG
    def listen_for_connections(self):
        self.sock2.bind((self.host, self.port))
        self.sock2.listen()
        while True:
            conn, addr = self.sock2.accept()
            self.connections.append(conn)
            threading.Thread(target=self.receive_message, args=(conn,)).start()
        
    def receive_message(self, conn):
        while True:
            try:
                data = conn.recv(2048)
                if not data:
                    #print("Received no data")
                    break
                received_message = data.decode()

                print(f"\nReceived message: {received_message}")
               # print(self.port)
                if received_message == "i_am_client":
                        #print("passed")
                        data = conn.recv(2048)
                        self.client_ip = data.decode()
                        print(f"\nReceived message: {self.client_ip}")
                        data = conn.recv(2048)
                        self.client_port = data.decode()
                        print(f"\nReceived message: {int(self.client_port)}")
                        
                        self.connect_client(self.client_ip, int(self.client_port))
                        data = conn.recv(2048)
                        self.command = data.decode()
                        if(self.command=='help'):
                            print('the availabe commands in this state are: create user|create poll|vote|view polls|view poll|view blockchain|view block|become validator|indendification validate')

                        elif (self.command=="create user"):   
                            self.user = user()
                            self.sock4.sendall('user has been succesufy created'.encode())
                            time.sleep(0.001)
                            self.sock4.sendall('user details:'.encode())
                            time.sleep(0.001)
                            self.sock4.sendall(("Private Key: {}".format(str(self.user.get_private_key()))).encode())
                            time.sleep(0.001)
                            self.sock4.sendall(("Public Key: {}".format(str(self.user.get_public_key()))).encode())
                            time.sleep(0.001)
                            self.sock4.sendall(("User Address: {}".format(str(self.user.get_user_address()))).encode())
                            time.sleep(0.001)

                            with open('txt\\users.txt', 'ab') as file:
                                pickle.dump(self.user, file)
                            self.broadcast_bootstrap('txt\\users.txt',None,self.host,self.port)

                        elif(self.command=="create poll"):
                            self.sock4.sendall('Enter the number of options: '.encode())
                            time.sleep(0.001)
                            data = conn.recv(2048)
                            self.poll_num = int(re.sub('[^0-9]+', '', data.decode()))
                            self.sock4.sendall('Enter the options separated by spaces: '.encode())
                            time.sleep(0.001)
                            data = conn.recv(2048)
                            self.datakek = data.decode()
                            self.poll_options_matrix = tuple(choice for choice in self.datakek.split())
                            self.sock4.sendall('Enter the name of the poll: '.encode())
                            data = conn.recv(2048)
                            self.poll_name = data.decode()
                            self.sock4.sendall('Enter your Private Key: '.encode())
                            data = conn.recv(2048)
                            private_key = data.decode()
                            check = 0
                            with open('txt\\users.txt', 'rb') as file:
                                while True:
                                    try:
                                        obj = pickle.load(file)
                                        if(obj.get_private_key() == private_key):
                                            self.sock4.sendall('Poll has been successfully created'.encode())
                                            poll_obj = poll(self.poll_num, self.poll_options_matrix, self.poll_name)
                                            poll_address = poll_obj.get_poll_address()
                                            self.sock4.sendall(format(poll_address).encode())
                                            with open('txt\\polls.txt', 'ab') as file2:
                                                pickle.dump(poll_obj, file2)
                                            self.broadcast_bootstrap('txt\\polls.txt',None,self.host,self.port)
                                            check = 1
                                    except EOFError:
                                        break
                            if check == 0:
                                self.sock4.sendall('Error to create poll, Private key not found'.encode())
                            
                        
                        elif (self.command == "vote"):
                                self.sock4.sendall('Enter poll address:'.encode())
                                time.sleep(0.1)
                                print("hello before")
                                data = conn.recv(2048)
                                self.voting_address = data.decode()
                                changed = False
                                print("hello aftetr")
                                with open('txt\\polls.txt', 'rb') as file:
                                    objects = []
                                    while True:
                                        try:
                                            obj = pickle.load(file)
                                            if obj.get_poll_address2() == self.voting_address:
                                                self.sock4.sendall('Enter your vote:'.encode())
                                                time.sleep(0.1)
                                                data = conn.recv(2048)
                                                self.vote = data.decode()
                                                self.sock4.sendall('Enter your private key:'.encode())
                                                time.sleep(0.1)
                                                data = conn.recv(2048)
                                                privatekey = data.decode()
                                                with open('txt\\users.txt', 'rb') as file2:
                                                    while True:
                                                        try:
                                                            obj2 = pickle.load(file2)
                                                            if (obj2.get_private_key() == privatekey):
                                                                obj.vote(self.vote)
                                                                changed = True
                                                                self.sock4.sendall(
                                                                    'Your vote has been succesfully submitted'.encode())
                                                                time.sleep(0.1)
                                                                last_object = None
                                                                with open('txt\\vote_chain.txt', 'rb') as file4:
                                                                    while True:
                                                                        try:
                                                                            last_object = pickle.load(file4)
                                                                        except EOFError:
                                                                            break

                                                                vote_block = voteblock(
                                                                    str(self.voting_address),
                                                                    str(self.vote),
                                                                    str(obj.vote_counter_poll_options[
                                                                            obj.poll_options_map[self.vote]]),
                                                                    str(obj.get_total_vote_counter()),
                                                                    str(obj2.get_user_address()),
                                                                    str(last_object.get_block_hash())
                                                                )
                                                                self.sock4.sendall(
                                                                    str('Your votes block hash: ' + vote_block.get_block_hash()).encode())
                                                                time.sleep(0.1)
                                                                with open('txt\\vote_chain.txt', 'ab') as file3:
                                                                    pickle.dump(vote_block, file3)
                                                        except EOFError:
                                                            break
                                            objects.append(obj)
                                        except EOFError:
                                            break
                                if (changed):
                                    print("changed")
                                    with open('txt\\polls.txt', 'wb') as file5:
                                        for obj in objects:
                                            pickle.dump(obj, file5)
                                    self.broadcast_bootstrap('txt\\polls.txt', None, self.host, self.port)
                                    time.sleep(2)
                                    self.broadcast_bootstrap('txt\\vote_chain.txt', None, self.host, self.port)
                                    time.sleep(0.001)
                                else:
                                    self.sock4.sendall('Error voting'.encode())
                            


                        elif self.command == "view users":
                            with open('txt\\users.txt', 'rb') as file:
                                while True:
                                    try:
                                        loaded_object = pickle.load(file)
                                        self.sock4.sendall('\n'.encode())
                                        time.sleep(0.001)
                                        self.sock4.sendall(str(loaded_object.to_string()).encode())
                                        time.sleep(0.001)
                                    except EOFError:
                                        break

                        elif self.command == "view polls":
                            with open('txt\\polls.txt', 'rb') as file:
                                while True:
                                    try:
                                        loaded_object = pickle.load(file)
                                        self.sock4.sendall('\n'.encode())
                                        time.sleep(0.001)
                                        self.sock4.sendall(str(loaded_object.to_string()).encode())
                                        time.sleep(0.001)
                                    except EOFError:
                                        break
 

                        elif(self.command=="view poll"):
                            self.sock4.sendall('Enter poll address:'.encode())
                            data = conn.recv(2048)
                            self.voting_address = data.decode()
                            changed=False
                            with open('txt\\polls.txt', 'rb') as file:
                                while True:
                                    try:
                                        obj = pickle.load(file)
                                        if obj.get_poll_address2() == self.voting_address:
                                            msg = ("Poll name: " + obj.get_poll_name())
                                            self.sock4.sendall(msg.encode('utf-8'))
                                            time.sleep(0.001)
                                            msg = ("Poll options: " + str(obj.get_poll_options()))
                                            self.sock4.sendall(msg.encode('utf-8'))
                                            time.sleep(0.001)
                                            msg = ("Vote counter poll options: " + obj.get_vote_counter_poll_options())
                                            self.sock4.sendall(msg.encode('utf-8'))
                                            time.sleep(0.001)
                                            msg = ("Total vote counter: " + obj.get_total_vote_counter())
                                            self.sock4.sendall(msg.encode('utf-8'))
                                            time.sleep(0.001)
                                            changed = True
                                    except EOFError:
                                        break
                            if (changed == False):
                                self.sock4.sendall('Poll address not found'.encode())

                        elif(self.command=="view blockchain"):
                               with open('txt\\vote_chain.txt', 'rb') as file:
                                    while True:
                                        try:
                                            obj = pickle.load(file)
                                            self.sock4.sendall(('\n').encode())
                                            time.sleep(0.001)
                                            self.sock4.sendall(("Block data: " + str(obj.get_block_data())).encode('utf-8'))
                                            time.sleep(0.001)
                                            self.sock4.sendall(("Block hash: " + str(obj.get_block_hash())).encode('utf-8'))
                                            time.sleep(0.001)
                                        except EOFError:
                                            break

                        elif(self.command=="view block"):
                            self.sock4.sendall(('Enter blocks hash:').encode())
                            time.sleep(0.001)
                            data = conn.recv(2048)
                            with open('txt\\vote_chain.txt', 'rb') as file:
                                    while True:
                                        try:
                                            obj = pickle.load(file)
                                            if obj.get_block_hash() == data.decode():
                                                self.sock4.sendall(('\n').encode())
                                                time.sleep(0.001)
                                                self.sock4.sendall(("Block data: " + str(obj.get_block_data())).encode('utf-8'))
                                                time.sleep(0.001)
                                                
                                                break
                                        except EOFError:
                                            break
                        
                        
                        elif (self.command == "become validator"):
                            data = conn.recv(1024)
                            if data.decode() == "b'Y'" or data.decode() == "b'y'":
                                self.sock4.sendall("become validator".encode())
                                time.sleep(0.001)
                                # my_ip2 = self.get_public_ip()
                                # self.sock4.sendall(my_ip2.encode())
                                # time.sleep(0.5)
                                self.sock4.sendall(str(self.bootstrap_host_next).encode())
                                time.sleep(0.001)

                                self.sock4.sendall(str(self.bootstrap_port_next).encode())
                                time.sleep(0.001)

                                # my_ip = self.get_public_ip()
                                # self.sock4.sendall(my_ip.encode())
                                # time.sleep(0.5)

                                self.sock4.sendall(str(self.host).encode())
                                time.sleep(0.001)

                                self.sock4.sendall(str(self.port).encode())
                                time.sleep(0.001)

                                self.sock3.sendall('Close connection'.encode())
                                time.sleep(0.001)
                                self.sock3.sendall(self.client_ip.encode())
                                time.sleep(0.001)
                                self.sock3.sendall(str(self.client_port).encode())
                                time.sleep(0.001)

                            
                                self.sock3.shutdown(socket.SHUT_RDWR)
                                self.sock3.close()
                                time.sleep(5)
                                self.connect_bootstrap_next(self.client_ip, int(self.client_port))
                                time.sleep(0.001)
                                self.sock3.sendall('Update files'.encode())
                                time.sleep(0.001)
                                try:
                                    folder_path = 'txt'
                                    files = os.listdir(folder_path)
                                    num_files = len(files)
                                    self.sock3.sendall(str(num_files).encode())
                                    time.sleep(0.001)
                                    for file_name in files:
                                        file_path = os.path.join(folder_path, file_name)
                                        with open(file_path, 'rb') as f:
                                            file_contents = f.read()

                                        self.sock3.sendall(file_name.encode())
                                        time.sleep(0.001)

                                        self.sock3.sendall(file_contents)
                                        time.sleep(0.001)
                                        received_msg = self.sock3.recv(2048).decode() 
                                        if received_msg == "continue":
                                            print ("CONTINUE")    
                                               
                                      #  print ("at the end of the loop")                  
                                    print('Folder contents sent successfully.')
                                except Exception as e:
                                    print('Error sending folder contents:', e)
                                
                        
                        elif(self.command=="update initial bootstraps"):
                            with open('txt\\initial_bootstraps.txt', 'r') as file:
                                file_contents = file.read()
                            self.sock4.sendall('update initial bootstraps'.encode())
                            self.sock4.sendall(file_contents.encode())
                        
                        #when the comands procedure come to an end, close the connecetion    
                        self.sock4.shutdown(socket.SHUT_RDWR)
                        self.sock4.close()
                        self.sock4 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        self.sock4.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                
            ########## this is outside of i am client if statement

                elif (received_message == "Update from bootstrap"):
                  #  print("WE ENTER THE UPDATE FILE SECTION")
                    data = conn.recv(1024)
                    sender = data.decode()
                    print("Sender ip", sender)

                    data = conn.recv(1024)
                    sender_port = data.decode()
                    print("Sender Port", sender_port)
                    time.sleep(0.001)

                    if sender == str(self.host) and sender_port == str(self.port):
                        print("I am the sender")
                        dataxd = conn.recv(1024)
                        time.sleep(0.001)
                        dataxd = conn.recv(1024 * 1024 * 1024)
                        time.sleep(0.001)
                    else:
                    
                        data = conn.recv(1024)
                        time.sleep(0.001)
                        updated_file_path = data.decode()
                        print("GOT THE FILE NAME:", updated_file_path)
                       
                        time.sleep(0.001)
                        data = conn.recv(1024 * 1024 * 1024)
                        contents = data
                        time.sleep(0.001)
                        with open(updated_file_path, 'wb') as f:
                            f.write(contents)
                        time.sleep(0.001)
                        print("SENDING TO NEXT")
                        self.broadcast_bootstrap(updated_file_path,contents ,sender, sender_port)

                elif (received_message == "Close connection"):
                        data = conn.recv(1024)
                        self.clientIP = data.decode()
                        
                        data = conn.recv(1024)
                        self.clientPort = data.decode()
                        
                        self.sock.shutdown(socket.SHUT_RDWR)
                        self.sock.close()
                        print("CLINET IP", self.clientIP)
                        print("CLIEN PORT", self.clientPort)
                        time.sleep(5)
                        self.connect_bootstrap_prev(self.clientIP, int(self.clientPort))
                
                elif (received_message == "Reconnect prev"):
        
                    data = conn.recv(1024)
                    next_ip = data.decode()
                    print("THE NEW NEXT IP IS", next_ip)
                    data = conn.recv(1024)
                    next_port = data.decode()
                    print("THE NEW  NEXT PORT IS", prev_port)
                    self.sock3.shutdown(socket.SHUT_RDWR)
                    self.sock3.close()
                    self.connect_bootstrap_next(next_ip, int(next_port))


                elif (received_message == "Reconnect next"):
                 
                
                    data = conn.recv(1024)
                    prev_ip = data.decode()
                    print("THE NEW PREV IP IS", prev_ip)
        
                    data = conn.recv(1024)
                    prev_port = data.decode()
                    print("THE NEW  PREV PORT IS", prev_port)
               
                    self.sock.shutdown(socket.SHUT_RDWR)
                    self.sock.close()
            
                    self.connect_bootstrap_prev(prev_ip, int(prev_port))

                elif received_message == "Update files":
                    try:
                        data = conn.recv(1024)
                        num_files = int(data.decode())
                        print('Receiving', num_files, 'files...')
                        save_dir = 'txt'
                        for _ in range(num_files):
                            data = conn.recv(1024)
                            file_name = data.decode()
                        
                            print("WE GET THE FILE NAME", file_name)
                            data2 = conn.recv(1024 * 1024 * 1024)
                            file_contents = data2
                            
                          
                            # Write the received file contents to disk
                            file_path = os.path.join(save_dir, file_name)
                            with open(file_path, 'wb') as f:
                                f.write(file_contents)
                            time.sleep(0.001)
                            conn.sendall('continue'.encode())
                        print('Files received successfully!')
                        with open('txt\\initial_bootstraps.txt', 'a') as file:
                            file.write('\n')
                            file.write(str(self.host) + ":" + str(self.port))
                        self.broadcast_bootstrap('txt\\initial_bootstraps.txt',None,self.host,self.port)
                    except Exception as e:
                        print('Error receiving folder contents:', e)
                   



                                
            except Exception as e:
                print("Error receiving message:", e)
                #print("Error receiving message:", e)
                # self.sock4.shutdown(socket.SHUT_RDWR)
                # self.sock4.close()
                # self.sock4 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                # self.sock4.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                break

        

if __name__ == '__main__':

    number = input("Enter your bootstrap's number: ")
    
    bootstrap1 = input("Enter your bootstrap's IP address: ")
    bootstrap_port1 = int(input("Enter your bootstrap's port number: "))
    
    bootstrap2 = input("Enter the bootstrap node's IP address: ")
    bootstrap_port2 = int(input("Enter the bootstrap node's port number: "))
    
    bootstrap3 = input("Enter the bootstrap node's IP address: ")
    bootstrap_port3 = int(input("Enter the bootstrap node's port number: "))
    lock = threading.Lock()

    # bootstrap1 = "127.0.0.1"
    # bootstrap_port1 = 4100
    
    # bootstrap2 = "127.0.0.1"
    # bootstrap_port2 = 4200
    
    # bootstrap3 = "127.0.0.1"
    # bootstrap_port3 = 4300

    node1 = Node(bootstrap1, bootstrap_port1)
    #print("i am bootstrap"+number)

    threading.Thread(target=node1.connect_bootstrap_next, args=(bootstrap2, bootstrap_port2)).start()
    threading.Thread(target=node1.connect_bootstrap_prev, args=(bootstrap3, bootstrap_port3)).start()
    threading.Thread(target=node1.listen_for_connections).start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        node1.on_death()
    
