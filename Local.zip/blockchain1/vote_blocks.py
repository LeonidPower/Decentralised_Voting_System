import hashlib

class voteblock:
#add SOS validator user_address
    def __init__(self,  poll_address, vote_option, vote_counter, total_vote_counter, user_address,previous_hash):
        self.poll_address = poll_address
        self.vote_option = vote_option
        self.vote_counter = vote_counter
        self.total_vote_counter = total_vote_counter
        self.user_address = user_address
        self.previous_hash = previous_hash

        self.block_data = poll_address + "-" + vote_option + "-" + vote_counter + "-" + total_vote_counter + "-" + user_address + "-" + previous_hash
        self.blcok_hash = hashlib.sha256(self.block_data.encode()).hexdigest()
        self.block= self.block_data + "\n" + self.blcok_hash

    def get_block_data(self):
        return self.block_data
    def get_block_hash(self):
        return self.blcok_hash
    def get_block(self):
        return self.block
    def to_string(self):
        return (f"{self.poll_address},{self.vote_option},{self.vote_counter},{self.total_vote_counter},{self.user_address},{self.previous_hash}")
    